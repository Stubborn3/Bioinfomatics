from itertools import product
import re

class DNA_Sequence:
    
    def readFile(self):
        listData  = []
        with open("inputData.txt",'r') as file:
            for line in file:
                listData.append(line.strip())
        return listData
            
    def generateSequence(self, length):
        listSeq = []
        for char in product('ACGT', repeat = length):
            listSeq.append("".join(char))
        return listSeq
    
    def listToString(self, seq):
        string = ""
        string += seq
        return string
    
    def replaceCharacter(self, wordSeq, position):
        listCharacter = list(wordSeq)
        listCharacter[position] = '.'
        return "".join(listCharacter)
    
    def printPattern(self,listOutput, case):
        word = ""
        for lst in listOutput:
            word += lst
            word += " "
        print("Case ",case,":",word)
        
        
    
    def findPattern(self):
        inputList = self.readFile()
        NLength = int(inputList[0])
        if(NLength < 1 or NLength > 100):
            print("N: Out of Range")
            return
        case = 0
        for string in inputList:
            if(string == inputList[0]):
                continue
            listInput = string.split(" ")
            tLength = int(listInput[0])
            if(tLength < 2 or tLength > 9):
                print("t: Out of Range")
                continue
            kLength = int(listInput[1])
            if(kLength < 2 or kLength > 9):
                print("k: Out of Range")
                continue
            listSequence = self.generateSequence(kLength)
            listOutput = []
            for sequence in listSequence:
                count = 0
                for stringWord in listInput:
                    if(stringWord == listInput[0] or stringWord == listInput[1]):
                        continue
                    word = ""
                    wordList = []
                    booleanFlag = False
                    seqNotMatch = 0
                    for position in range(kLength):
                        wordList = self.replaceCharacter(sequence,position)
                        word = self.listToString(wordList)
                        matchSeq = re.search(word,stringWord)
                        if(matchSeq):
                            booleanFlag = True
                            break
                        else:
                            seqNotMatch += 1
                    if(seqNotMatch == kLength):
                        break
                    if(booleanFlag):
                        count += 1
                if(count == tLength):
                    listOutput.append(sequence)
            if(listOutput != []):
                case += 1
                self.printPattern(listOutput,case)


def main():
    seq = DNA_Sequence()
    seq.findPattern()
    
if __name__ == "__main__":
    main()