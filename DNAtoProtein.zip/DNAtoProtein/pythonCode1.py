class geneToProtein:

    def readFile(self):
        listdata = []
        data  = ""
        with open("inputData.txt",'r') as file:
            line = int(file.readline().strip()) # total number of intron
            listdata.append(line)
            for i in range(line):
                listdata.append(file.readline().strip()) # intron location index
            for line in file:
                data += line.strip() # gene seqeuence
            listdata.append(data.upper())
            return listdata
    
    def condonTable(self):
        table = {"UUU":"F", "UUC":"F", "UUA":"L", "UUG":"L","UCU":"S", "UCC":"S", "UCA":"S", "UCG":"S",
                "UAU":"Y", "UAC":"Y", "UAA":"STOP", "UAG":"STOP","UGU":"C", "UGC":"C", "UGA":"STOP", "UGG":"W",
                "CUU":"L", "CUC":"L", "CUA":"L", "CUG":"L","CCU":"P", "CCC":"P", "CCA":"P", "CCG":"P",
                "CAU":"H", "CAC":"H", "CAA":"Q", "CAG":"Q","CGU":"R", "CGC":"R", "CGA":"R", "CGG":"R",
                "AUU":"I", "AUC":"I", "AUA":"I", "AUG":"M","ACU":"T", "ACC":"T", "ACA":"T", "ACG":"T",
                "AAU":"N", "AAC":"N", "AAA":"K", "AAG":"K","AGU":"S", "AGC":"S", "AGA":"R", "AGG":"R",
                "GUU":"V", "GUC":"V", "GUA":"V", "GUG":"V","GCU":"A", "GCC":"A", "GCA":"A", "GCG":"A",
                "GAU":"D", "GAC":"D", "GAA":"E", "GAG":"E","GGU":"G", "GGC":"G", "GGA":"G", "GGG":"G"}
        return table

    def RNATranscript(self,data):
        listData = list(data)
        for i in range(len(data)):
            if listData[i] == 'T':
                listData[i] = 'A'
            elif listData[i] == 'C':
                listData[i] = 'G'
            elif listData[i] == 'G':
                listData[i] = 'C'
            elif listData[i] == 'A':
                listData[i] = 'U'
        return "".join(listData)

    def createProtein(self,rData,table):
        protein = []
        aminoAcid = ""
        listData =list(rData)
        flag = False
        codon = ""
        for c in listData:
            codon += c
            if len(codon) == 3:
                if table[codon] == "M":
                    flag = True

                if table[codon] == "STOP" and flag == True:
                    aminoAcid += table[codon]
                    protein.append(aminoAcid)
                    aminoAcid = ""
                    flag = False

                elif flag == True:
                    aminoAcid += table[codon]
                    aminoAcid += "-"
                codon = ""
        return protein

    def printProtein(self, listProtein):
        i = 1
        for protein in listProtein:
            print("Protein("+str(i)+"): "+protein)
            i += 1
    
    def removeIntron(self,data,p1,p2):
        listData = list(data)
        for m in range(p1,p2+1):
            del listData[p1]
        return "".join(listData)
            

    def mainFunction(self):
        data = self.readFile()
        l1 = 0
        intronIndex = []
        cData = data[data[0]+1]
        for i in range(1,data[0]+1):
            intronIndex = data[i].split(" ")
            cData = self.removeIntron(cData,int(intronIndex[0])-l1,int(intronIndex[1])-l1)
            l1 += (int(intronIndex[1]) - int(intronIndex[0]))+1
        rData = self.RNATranscript(cData)
        table = self.condonTable()
        listProtein = self.createProtein(rData,table)
        self.printProtein(listProtein)



def main():
    gene = geneToProtein()
    gene.mainFunction()
    
if __name__ == "__main__":
    main()