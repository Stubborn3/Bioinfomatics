import numpy as np

class alignment:
	
	def matchOrMisMatch(self,s1,s2,penality):
		if s1 == s2:
			return penality["Match"]
		return penality["Mismatch"]
	
	def traceBackMatrix(self,a,b,c):
		m = max(a,b,c)
		if m == a:
			return "D"
		elif m == b:
			return "V"
		return "H"
					

	def optimalGlobalAlignment(self,seq1,seq2,matrix):
		row = len(seq2)-1
		column = len(seq1)-1
		list1 = []
		list2 = []
		while(True):
			if row == 0 and column == 0:
				break
			elif row == 0 and column != 0:
				for i in column:
					list1.insert(0,'-')
				break
			elif row != 0 and column == 0:
				for j in row:
					list2.insert(0,'-')
				break
			if matrix[row][column] == "D":
				list2.insert(0,seq1[column])
				list1.insert(0,seq2[row])
				row -= 1
				column -= 1
			elif matrix[row][column] == "V":
				list2.insert(0,'-')
				list1.insert(0,seq2[row])
				row -= 1
			elif matrix[row][column] == "H":
				list2.insert(0,seq1[column])
				list1.insert(0,'-')
				column -= 1
		print("".join(list2))
		print("".join(list1))
		print("---------------")
			
	def optimalLocalAlignment(self,seq1,seq2,matrixInt,matrixStr):
		result = np.where(matrixInt == np.amax(matrixInt))
		listOfCordinates = list(zip(result[0], result[1]))
		for cord in listOfCordinates:
			list1 = []
			list2 = []
			row = cord[0]
			column = cord[1]
			while True:
				if matrixInt[row][column] == 0:
					break
				elif matrixStr[row][column] == "D":
					list1.insert(0,seq2[row])
					list2.insert(0,seq1[column])
					row -= 1
					column -= 1

				elif matrixStr[row][column] == "V":
					list1.insert(0,seq2[row])
					list2.insert(0,"-")
					row -= 1
				else:
					list2.insert(0,seq1[column])
					list1.insert(0,"-")
					column -= 1
			print("".join(list2))
			print("".join(list1))
			print("---------------")

				
				
	
	
	def localAlignment(self,seq1,seq2,score):
		row = len(seq2)
		column = len(seq1)
		matrixAlignment = np.zeros((row,column), dtype = int)
		matrixAlignmentBack = np.zeros((row,column), dtype = str)
		for i in range(row):
			matrixAlignment[i][0] = 0
			matrixAlignmentBack[i][0] = "V"

		for j in range(column):
			matrixAlignment[0][j] = 0
			matrixAlignmentBack[0][j] = "H"

		matrixAlignment[0][0] = 0

		for i in range(1,row):
			for j in range(1,column):
				a = matrixAlignment[i-1][j-1] + self.matchOrMisMatch(seq1[j],seq2[i],score)
				b = matrixAlignment[i-1][j] + score["Indel"]
				c = matrixAlignment[i][j-1] + score["Indel"]
				matrixAlignment[i][j] = max(a,b,c,0)
				matrixAlignmentBack[i][j] = self.traceBackMatrix(a,b,c)
		print("Local Alignment Matrix")
		print(np.matrix(matrixAlignment))
		self.optimalLocalAlignment(seq1,seq2,matrixAlignment,matrixAlignmentBack)
		


	
	def globalAlignment(self,seq1,seq2,score):
		row = len(seq2)
		column = len(seq1)
		matrixAlignment = np.zeros((row,column), dtype = int)
		matrixAlignmentBack = np.zeros((row,column), dtype = str)
		for i in range(row):
			matrixAlignment[i][0] = score["Indel"] * i
			matrixAlignmentBack[i][0] = "V"

		for j in range(column):
			matrixAlignment[0][j] = score["Indel"] * j
			matrixAlignmentBack[0][j] = "H"

		matrixAlignment[0][0] = 0

		for i in range(1,row):
			for j in range(1,column):
				a = matrixAlignment[i-1][j-1] + self.matchOrMisMatch(seq1[j],seq2[i],score)
				b = matrixAlignment[i-1][j] + score["Indel"]
				c = matrixAlignment[i][j-1] + score["Indel"]
				matrixAlignment[i][j] = max(a,b,c)
				matrixAlignmentBack[i][j] = self.traceBackMatrix(a,b,c)
		print("Global Alignment Matrix")
		print(np.matrix(matrixAlignment))
		self.optimalGlobalAlignment(seq1,seq2,matrixAlignmentBack)

	def readInFile(self):
		with open("readData.txt",'r') as file:
			size = int(file.readline().strip())
			for i in range(size):
				seq1 = "-"
				seq2 = "-"
				line = file.readline().strip().split(" ")
				match = int(line[0])
				misMatch = int(line[1])
				indel = int(line[2])
				seq1 += file.readline().strip()
				seq2 += file.readline().strip()
				scorePenality = {"Match":match,"Mismatch":misMatch,"Indel":indel}
				self.globalAlignment(seq1,seq2,scorePenality)
				self.localAlignment(seq1,seq2,scorePenality)
		
def main():
	obj = alignment()
	obj.readInFile()
	
if __name__ == "__main__":
	main()
